import UIKit
import AVFoundation
import Vision

class ViewController: UIViewController {
    
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var faceDetectionRequest: VNRequest!
    var boundingBoxLayer: CALayer!
    var ovalFrame: CGRect!
    
    var lastLeftEyeOpen: Bool = true
    var lastRightEyeOpen: Bool = true
    var blinkCount: Int = 0
    var previousHeadPosition: CGPoint? = nil
    var blinkDetectionStartTime: Date?
    let requiredBlinkCount = 2
    let requiredBlinkTimeFrame: TimeInterval = 5.0
    
    var lastFrame: CVPixelBuffer?
    var motionDetected = true
    let motionThreshold: Float = 0.05 // Adjust based on sensitivity
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the capture session
        captureSession = AVCaptureSession()
        
        // Select the front camera
        guard let videoCaptureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else { return }
        
        let videoInput: AVCaptureDeviceInput
        
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            print("Failed to create video input")
            return
        }
        
        // Add input to the session
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            print("Unable to add input")
            return
        }
        
        // Create and configure the preview layer
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        
        // Start running the session
        captureSession.startRunning()
        
        // Apply the oval mask to the camera view
        applyOvalMask()
        
        // Initialize the bounding box layer
        boundingBoxLayer = CALayer()
        view.layer.addSublayer(boundingBoxLayer)
        
        // Start face detection with landmarks for blink detection
        startFaceDetection()
    }
    
    func applyOvalMask() {
        // Create a CAShapeLayer that defines the oval shape
        let maskLayer = CAShapeLayer()
        
        // Define the oval path and store its frame
        ovalFrame = CGRect(x: (view.bounds.width - 200) / 2,
                           y: (view.bounds.height - 300) / 2,
                           width: 200,
                           height: 300)
        let ovalPath = UIBezierPath(ovalIn: ovalFrame)
        
        // Assign the path to the mask layer
        maskLayer.path = ovalPath.cgPath
        
        // Apply the mask to the preview layer
        previewLayer.mask = maskLayer
    }
    
    @objc func capturePhoto() {
        // Implement photo capture functionality here
        print("Capture button tapped")
    }
    
    func startFaceDetection() {
        // Set up the face detection request with landmarks
        faceDetectionRequest = VNDetectFaceLandmarksRequest(completionHandler: { [weak self] (request, error) in
            if let results = request.results as? [VNFaceObservation] {
                DispatchQueue.main.async {
                    self?.handleFaces(results)
                }
            }
        })
        
        // Set up the video output
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Unable to add video output")
        }
    }
    
    func handleFaces(_ faces: [VNFaceObservation]) {
        // Clear previous bounding boxes
        boundingBoxLayer.sublayers?.forEach { $0.removeFromSuperlayer() }
        
        for face in faces {
            // Get face landmarks
            guard let landmarks = face.landmarks else { continue }
            
            if let leftEye = landmarks.leftEye, let rightEye = landmarks.rightEye {
                // Detect eye openness (liveness heuristic)
                let leftEyeOpen = isEyeOpen(eye: leftEye)
                let rightEyeOpen = isEyeOpen(eye: rightEye)
                
                if !leftEyeOpen && !rightEyeOpen {
                    if lastLeftEyeOpen && lastRightEyeOpen {
                        handleBlinkDetection()
                    }
                }
                
                lastLeftEyeOpen = leftEyeOpen
                lastRightEyeOpen = rightEyeOpen
            }
            
            // Track head movement
            trackHeadMovement(face: face)
            
            // Convert bounding box from normalized coordinates to the view's coordinate system
            let size = CGSize(width: face.boundingBox.width * view.bounds.width,
                              height: face.boundingBox.height * view.bounds.height)
            let origin = CGPoint(x: face.boundingBox.origin.x * view.bounds.width,
                                 y: (1 - face.boundingBox.origin.y - face.boundingBox.height) * view.bounds.height) // Adjust for coordinate system
            
            let faceFrame = CGRect(origin: origin, size: size)
            
            // Check if the faceFrame is within the ovalFrame
            if ovalFrame.contains(faceFrame) {
                // Create an oval-shaped green border around the detected face
                let ovalLayer = CAShapeLayer()
                ovalLayer.path = UIBezierPath(ovalIn: ovalFrame).cgPath
                ovalLayer.strokeColor = UIColor.green.cgColor
                ovalLayer.fillColor = UIColor.clear.cgColor
                ovalLayer.lineWidth = 3.0
                
                // Add the oval layer to the bounding box layer
                boundingBoxLayer.addSublayer(ovalLayer)
                
                print("Face perfectly detected within oval!")
            }
        }
    }
    
    func isEyeOpen(eye: VNFaceLandmarkRegion2D) -> Bool {
        // Calculate the distance between the top and bottom points of the eye
        let verticalDistance = hypot(eye.normalizedPoints[1].x - eye.normalizedPoints[5].x,
                                     eye.normalizedPoints[1].y - eye.normalizedPoints[5].y)
        // Heuristic: if the distance is small, the eye is closed
        return verticalDistance > 0.03
    }
    
    func handleBlinkDetection() {
        if blinkDetectionStartTime == nil {
            blinkDetectionStartTime = Date()
        }
        // Increment blink count
        blinkCount += 1
        print("Blink detected, total blinks: \(blinkCount)")
        
        // Check if blink count is sufficient within the timeframe
        if blinkCount >= requiredBlinkCount {
            if let startTime = blinkDetectionStartTime, Date().timeIntervalSince(startTime) <= requiredBlinkTimeFrame {
                print("Liveness confirmed via blink detection!")
                // Reset blink count and timer
                blinkCount = 0
                blinkDetectionStartTime = nil
            }
        }
    }
    
    func trackHeadMovement(face: VNFaceObservation) {
        
        let currentHeadPosition = CGPoint(x: face.boundingBox.midX, y: face.boundingBox.midY)
        
        if let previousPosition = previousHeadPosition {
            let distanceMoved = hypot(currentHeadPosition.x - previousPosition.x, currentHeadPosition.y - previousPosition.y)
            
            // If head movement is significant (beyond a small threshold), it's likely a real person
            if distanceMoved > 0.01 {
                print("Head movement detected, liveness confirmed!")
            }
        }
        previousHeadPosition = currentHeadPosition
    }
}

extension ViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Get a CVPixelBuffer from the sample buffer
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        // Analyze motion to determine if the input is an image or video
        analyzeMotion(currentFrame: pixelBuffer)
        
        // Proceed with face detection only if motion is detected
        if motionDetected {
            // Create a request handler using the pixel buffer
            let requestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            // Perform face detection
            try? requestHandler.perform([faceDetectionRequest])
        } else {
            print("Input appears to be a still image.")
            // Handle still image logic if needed
        }
    }
    
    func analyzeMotion(currentFrame: CVPixelBuffer) {
        guard let lastFrame = lastFrame else {
            // First frame, treat as moving
            self.lastFrame = currentFrame
            motionDetected = true
            return
        }
        
        // Compare current frame with last frame to detect motion
        let difference = compareFrames(current: currentFrame, last: lastFrame)
        motionDetected = difference > motionThreshold // Check against threshold
        
        // Update lastFrame to current
        self.lastFrame = currentFrame
    }
    
    func compareFrames(current: CVPixelBuffer, last: CVPixelBuffer) -> Float {
        // Convert CVPixelBuffer to CIImage
        let currentImage = CIImage(cvPixelBuffer: current)
        let lastImage = CIImage(cvPixelBuffer: last)
        
        // Create context for image processing
        let context = CIContext()
        
        // Calculate the difference between the two images
        guard let currentCGImage = context.createCGImage(currentImage, from: currentImage.extent),
              let lastCGImage = context.createCGImage(lastImage, from: lastImage.extent) else {
            return 0.0
        }
        
        // Create a difference filter
        let differenceFilter = CIFilter(name: "CISubtractBlendMode")
        differenceFilter?.setValue(currentImage, forKey: kCIInputImageKey)
        differenceFilter?.setValue(lastImage, forKey: kCIInputBackgroundImageKey)
        
        // Get the output image
        guard let outputImage = differenceFilter?.outputImage else { return 0.0 }
        
        // Create a bitmap representation of the output
        let outputBitmap = context.createCGImage(outputImage, from: outputImage.extent)
        
        // Calculate the pixel difference (count non-zero pixels)
        let pixelData = outputBitmap?.dataProvider?.data
        let data: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        
        var nonZeroCount: Int = 0
        let width = outputBitmap?.width ?? 0
        let height = outputBitmap?.height ?? 0
        
        // Count the number of non-zero pixels
        for y in 0..<height {
            for x in 0..<width {
                let pixelIndex = (y * width + x) * 4 // RGBA
                if data[pixelIndex] > 0 { // Check if red channel is non-zero
                    nonZeroCount += 1
                }
            }
        }
        
        // Calculate the difference as a proportion of total pixels
        let totalPixels = width * height
        return Float(nonZeroCount) / Float(totalPixels)
    }
}


